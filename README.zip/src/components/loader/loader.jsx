import React from "react";
import "./loader.css";
function Loader() {
  return (
    <div>
      {" "}
      <div className="main_loader_container">
        <div className="loader"></div>
      </div>
    </div>
  );
}

export default Loader;
